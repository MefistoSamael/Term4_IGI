from tests.data import my_func, my_decorator, for_dec, A, B, C
