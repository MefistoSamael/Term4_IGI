import sir_Bychko_serializer.serialiser
from sir_Bychko_serializer.serialiser import serialize, deserialize

def my_func(a):
    return a+2

ser = serialize(my_func)

deser = deserialize(ser)

print(deser(2))

