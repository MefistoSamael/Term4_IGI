Ne prividi gospod' vi polezete v ety biblioteku. Ono vam ne nado

Desine sperare qui hic intras
-
Lasciate ogne speranza, voi ch’entrate
-
Abandon hope, all ye who enter here
-
Lasst alle Hoffnung fahren, die ihr hier eintretet
-
Oh, los que entrais, dejad toda esperanza
-
Оставь надежду, всяк сюда входящий
-